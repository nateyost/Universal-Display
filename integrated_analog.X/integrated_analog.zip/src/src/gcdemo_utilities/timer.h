#ifndef TIMER_H
#define TIMER_H

#ifdef __cpluslus
	extern "C" {
#endif // __cplusplus

#include <stdint.h>



#ifdef __cplusplus
	}
#endif // __cplusplus

#endif //TIMER_TCKPS2LITERAL_U16_H

